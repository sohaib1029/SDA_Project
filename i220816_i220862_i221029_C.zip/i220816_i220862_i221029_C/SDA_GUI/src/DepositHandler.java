public class DepositHandler {
    public int deposit(int amount) {
        if (User.getInstance().getFlagged()) {
            System.out.println("You have been flagged by the system and cannot perform this operation. Kindly contact the admin for further explanation.");
            return 1;
        }
        if (amount <= 0) {
            System.out.println("Deposit failed: Amount must be greater than zero.");
            return 2;
        }
        int oldBalance = User.getInstance().getBalance();
        int newBalance = User.getInstance().getBalance() + amount;
        DBHandler.getInstance().addFund(User.getInstance().getId(), oldBalance, newBalance, newBalance - oldBalance);
        User.getInstance().setBalance(newBalance);
        System.out.println("Deposit successful! New balance: $" + User.getInstance().getBalance());
        return 3;
    }
}
