import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import java.awt.*;
import java.awt.event.*;

public class LoginScreen {
    JFrame frame;
    JButton userBtn;
    JButton adminBtn;
    JTextField userNameText;
    JPasswordField passText;
    Border defaultBtnBorder;
    Border hoverBtnBorder;
    MouseAdapter buttonMouseListener;
    FocusAdapter buttonFocusListener;
    private DBFacade dbFacade;

    LoginScreen() {
        dbFacade = new DBFacade();
        defaultBtnBorder = new EtchedBorder(1, Color.DARK_GRAY, Color.LIGHT_GRAY);
        hoverBtnBorder = new EtchedBorder(1, Color.GRAY, Color.DARK_GRAY);
        // Create common mouse and focus listeners
        buttonMouseListener = UIUtils.createButtonMouseListener(defaultBtnBorder, hoverBtnBorder);
        buttonFocusListener = UIUtils.createButtonFocusListener(defaultBtnBorder, hoverBtnBorder);

        frame = UIUtils.createFrame("Casino Management System", 275, 50, 800, 600, true);
        JLayeredPane mainPane = UIUtils.createPane(0, 0, 800, 600);
        JLabel backgroundImageLabel = UIUtils.createLabel("", 0, 0, 800, 600, null, null, null, null ,0);
        UIUtils.imageIcon(backgroundImageLabel, "C:\\Users\\Students\\Downloads\\resources_sda_project\\bckg_login.png");
        UIUtils.imageIcon(frame, "C:\\Users\\Students\\Downloads\\resources_sda_project\\casino_logo.jpg");

        userBtn = UIUtils.createButton("User", 70, 220, 100, 30, new Font("Comic Sans", Font.ITALIC, 22), Color.WHITE, false, defaultBtnBorder);
        adminBtn = UIUtils.createButton("Management", 230, 220, 200, 30, new Font("Comic Sans", Font.ITALIC, 22), Color.WHITE, false, defaultBtnBorder);
        JButton submitBtn = UIUtils.createButton("Submit", 200, 450, 130, 30, new Font("Comic Sans", Font.BOLD, 22), Color.WHITE, false, defaultBtnBorder);
        JButton showBtn = UIUtils.createButton("Show", 380, 390, 50, 30, new Font("Comic Sans", Font.PLAIN, 14), Color.WHITE, false, defaultBtnBorder);

        JLabel loginLabel = UIUtils.createLabel("Login Portal for Users / Management", 30, 150, 500, 50, new Font("Comic Sans", Font.BOLD, 25), Color.WHITE, null, null, 2);
        JLabel userNameLabel = UIUtils.createLabel("Username:", 70, 300, 150, 40, new Font("Comic Sans", Font.ITALIC, 22), Color.WHITE, null, null, 2);
        JLabel passLabel = UIUtils.createLabel("Password:", 70, 350, 150, 40, new Font("Comic Sans", Font.ITALIC, 22), Color.WHITE, null, null, 2);

        userNameText = UIUtils.createTextField(230, 305, 200, 30, new Font("Consolas", Font.PLAIN, 22), Color.WHITE, Color.GRAY, Color.WHITE, "Enter Username", new Insets(5, 5, -1, 0));
        passText = UIUtils.createPassField(230, 353, 200, 30, new Font("Consolas", Font.PLAIN, 22), Color.WHITE, Color.GRAY, Color.WHITE, "Enter Password", new Insets(5, 5, -1, 0));

        // Add listeners for all buttons
        addButtonListeners(userBtn, "User");
        addButtonListeners(adminBtn, "Management");
        addButtonListeners(submitBtn, "Submit");
        addButtonListeners(showBtn, "Show");

        mainPane.add(backgroundImageLabel, JLayeredPane.DEFAULT_LAYER);
        mainPane.add(userBtn, JLayeredPane.PALETTE_LAYER);
        mainPane.add(adminBtn, JLayeredPane.PALETTE_LAYER);
        mainPane.add(submitBtn, JLayeredPane.PALETTE_LAYER);
        mainPane.add(showBtn, JLayeredPane.PALETTE_LAYER);
        mainPane.add(loginLabel, JLayeredPane.PALETTE_LAYER);
        mainPane.add(userNameLabel, JLayeredPane.PALETTE_LAYER);
        mainPane.add(passLabel, JLayeredPane.PALETTE_LAYER);
        mainPane.add(userNameText, JLayeredPane.PALETTE_LAYER);
        mainPane.add(passText, JLayeredPane.PALETTE_LAYER);

        frame.setContentPane(mainPane);
    }

    // Generic method to add mouse, focus, and action listeners to buttons
    private void addButtonListeners(JButton button, String buttonLabel) {
        button.addActionListener(createButtonActionListener(buttonLabel));
        button.addMouseListener(buttonMouseListener);
        button.addFocusListener(buttonFocusListener);
    }

    // Method to create button-specific action listeners
    private ActionListener createButtonActionListener(String buttonLabel) {
        return new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton source = (JButton) e.getSource();
                switch (buttonLabel) {
                    case "User":
                    case "Management":
                        userBtn.setContentAreaFilled(false);
                        userBtn.setBackground(null);
                        adminBtn.setContentAreaFilled(false);
                        adminBtn.setBackground(null);
                        source.setContentAreaFilled(true);
                        source.setBackground(Color.GRAY);
                        break;
                    case "Show":
                        source.setContentAreaFilled(true);
                        source.setBackground(Color.DARK_GRAY);

                        // Use a timer to revert the appearance after a short delay (delay of 100 ms i.e., click and release)
                        Timer timer = new Timer(100, event -> {
                            source.setBackground(UIManager.getColor("Button.background"));
                            source.setContentAreaFilled(false);
                        });
                        timer.setRepeats(false);
                        timer.start();

                        if (passText.getEchoChar() == '●') {
                            passText.setEchoChar((char) 0); // Reveal password
                            source.setText("Hide");
                        }
                        else {
                            passText.setEchoChar('●'); // Hide password
                            source.setText("Show");
                        }
                        break;
                    case "Submit":
                        source.setContentAreaFilled(true);
                        source.setBackground(Color.GRAY);

                        // Use a timer to revert the appearance after a short delay (delay of 100 ms i.e., click and release)
                        timer = new Timer(100, event -> {
                            source.setBackground(UIManager.getColor("Button.background"));
                            source.setContentAreaFilled(false);
                        });
                        timer.setRepeats(false);
                        timer.start();

                        // Determine which option is selected
                        boolean isUserSelected = userBtn.getBackground().equals(Color.GRAY);
                        boolean isManagementSelected = adminBtn.getBackground().equals(Color.GRAY);
                        if (!isUserSelected && !isManagementSelected) {
                            JOptionPane.showMessageDialog(
                                    frame,
                                    "Please select an option (User/Management)!",
                                    "No Option Selected",
                                    JOptionPane.WARNING_MESSAGE
                            );
                            return;
                        }

                        String username = userNameText.getText().trim();
                        String password = passText.getText().trim();
                        // Check if username and password are entered
                        if (username.isEmpty() || password.isEmpty()) {
                            JOptionPane.showMessageDialog(
                                    frame,
                                    "Please enter both username and password!",
                                    "Missing Details",
                                    JOptionPane.WARNING_MESSAGE
                            );
                            return;
                        }

                        // Check database for username and password
                        boolean isAuthenticated = false;

                        if (isUserSelected) {
                            // Call user authentication method
                            isAuthenticated = dbFacade.authenticateUser(username, password, false);
                        }
                        else if (isManagementSelected) {
                            // Call management authentication method
                            isAuthenticated = dbFacade.authenticateUser(username, password, true);
                        }

                        // Handle authentication result
                        if (isAuthenticated) {
                            JOptionPane.showMessageDialog(
                                    frame,
                                    "Login successful! Welcome!",
                                    "Success",
                                    JOptionPane.INFORMATION_MESSAGE
                            );
                            if (isManagementSelected) {
                                dbFacade.getManagerDetails(username, Manager.getInstance());
                                openNextWindow(adminBtn.getText()); // Open the next window
                            }
                            else {
                                dbFacade.getUserDetails(username, User.getInstance());
                                openNextWindow(userBtn.getText()); // Open the next window
                            }
                        }
                        else {
                            JOptionPane.showMessageDialog(
                                    frame,
                                    "Incorrect username or password. Please try again.",
                                    "Authentication Failed",
                                    JOptionPane.ERROR_MESSAGE
                            );
                        }
                        break;
                }
            }
        };
    }

//    private boolean authenticateUser(String username, String password) {
//        // Simulate a database query for user authentication
//        // Replace with actual database logic
//        return username.equals("user") && password.equals("password"); // Example credentials
//    }
//
//    private boolean authenticateManagement(String username, String password) {
//        // Simulate a database query for management authentication
//        // Replace with actual database logic
//        return username.equals("admin") && password.equals("admin123"); // Example credentials
//    }

    private void openNextWindow(String buttonLabel) {
        // Use the factory to create the appropriate screen
        Object nextScreen = ScreenFactory.createScreen(buttonLabel, this.frame);

        frame.dispose();
    }
}
