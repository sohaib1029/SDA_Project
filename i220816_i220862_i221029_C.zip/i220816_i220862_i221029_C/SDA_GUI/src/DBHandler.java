import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DBHandler extends PersistenceHandler {
    private Connection conn;
    private static DBHandler instance;

    private DBHandler() {
        openConnection();
    }

    // Public method to get the single instance
    public static DBHandler getInstance() {
        if (instance == null) {
            synchronized (DBHandler.class) {
                if (instance == null) {
                    instance = new DBHandler();
                }
            }
        }
        return instance;
    }

    public static void resetInstance() {
        instance.closeConnection();
        instance = null;
    }

    private void createDatabase() {
        try {
            Statement statement0 = conn.createStatement();

            // Check if the target database exists
            // Perform SQL operations
            String checkDbExists = "SELECT 1 FROM pg_database WHERE datname = '" + "cms" + "';";
            ResultSet rs = statement0.executeQuery(checkDbExists);

            // Create database if it doesn't exist
            if (!rs.next()) {
                System.out.println("Database does not exist. Creating it...");
                statement0.executeUpdate("CREATE DATABASE cms");
                System.out.println("Database created.");
                try {
                    Thread.sleep(1000);
                }
                catch (InterruptedException e) {
                    System.out.println("Sleep interrupted: " + e.getMessage());
                }
                this.closeConnection(); // Closing previous connection
                conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/cms", "postgres", "12344");
                System.out.println("Database connected.");
                Statement statement = conn.createStatement();
                String createTableUsers = "CREATE TABLE IF NOT EXISTS USERS (" +
                        "userID VARCHAR(50) PRIMARY KEY, " +
                        "fullName VARCHAR(100), " +
                        "email VARCHAR(100) UNIQUE, " +
                        "address VARCHAR(250), " +
                        "password VARCHAR(50) UNIQUE, " +
                        "age INT, " +
                        "loyaltyPoints INT DEFAULT 0, " +
                        "balance INT DEFAULT 0, " +
                        "flagged BOOLEAN DEFAULT FALSE);";
                try {
                    statement.execute(createTableUsers);
                    System.out.println("Users table created successfully.");
                }
                catch (SQLException e) {
                    System.out.println("Error creating Users table: " + e.getMessage());
                }
                String createTableAdmin = "CREATE TABLE IF NOT EXISTS MANAGERS (" +
                        "managerID VARCHAR(50) PRIMARY KEY, " +
                        "fullName VARCHAR(100), " +
                        "email VARCHAR(100) UNIQUE, " +
                        "address VARCHAR(250), " +
                        "password VARCHAR(250) UNIQUE);";
                try {
                    statement.execute(createTableAdmin);
                    System.out.println("Managers table created successfully.");
                }
                catch (SQLException e) {
                    System.out.println("Error creating Managers table: " + e.getMessage());
                }
                String createTableGames = "CREATE TABLE IF NOT EXISTS GAMES (" +
                        "gameID SERIAL PRIMARY KEY, " +
                        "gameName VARCHAR(50), " +
                        "winMx INT DEFAULT 0);";
                try {
                    statement.execute(createTableGames);
                    System.out.println("Games table created successfully.");
                }
                catch (SQLException e) {
                    System.out.println("Error creating Games table: " + e.getMessage());
                }
                String createTableRewards = "CREATE TABLE IF NOT EXISTS REWARDS (" +
                        "rewardID SERIAL PRIMARY KEY, " +
                        "rewardName VARCHAR(50), " +
                        "rewardPoints INT DEFAULT 0, " +
                        "rewardInStock INT DEFAULT 0, " +
                        "rewardImagePath VARCHAR(250));";
                try {
                    statement.execute(createTableRewards);
                    System.out.println("Rewards table created successfully.");
                }
                catch (SQLException e) {
                    System.out.println("Error creating Rewards table: " + e.getMessage());
                }
                String createTableRedeem = "CREATE TABLE IF NOT EXISTS REDEEM (" +
                        "redeemID SERIAL PRIMARY KEY, " +
                        "userID VARCHAR(50), " +
                        "rewardID INT, " +
                        "redeemedAt TIMESTAMP DEFAULT NOW(), " +
                        "FOREIGN KEY (userID) REFERENCES USERS(userID), " +
                        "FOREIGN KEY (rewardID) REFERENCES REWARDS(rewardID));";
                try {
                    statement.execute(createTableRedeem);
                    System.out.println("Redeem table created successfully.");
                }
                catch (SQLException e) {
                    System.out.println("Error creating Redeem table: " + e.getMessage());
                }
                String createTableMatches = "CREATE TABLE IF NOT EXISTS MATCHES (" +
                        "matchID SERIAL PRIMARY KEY, " +
                        "userID VARCHAR(50), " +
                        "gameID INT NOT NULL, " +
                        "betAmount INT DEFAULT 0, " +
                        "result BOOLEAN DEFAULT TRUE, " +
                        "playedAt TIMESTAMP DEFAULT NOW(), " +
                        "FOREIGN KEY (userID) REFERENCES USERS(userID), " +
                        "FOREIGN KEY (gameID) REFERENCES GAMES(gameID));";
                try {
                    statement.execute(createTableMatches);
                    System.out.println("Matches table created successfully.");
                }
                catch (SQLException e) {
                    System.out.println("Error creating Matches table: " + e.getMessage());
                }
                String createTableFunds = "CREATE TABLE IF NOT EXISTS FUNDS (" +
                        "fundID SERIAL PRIMARY KEY, " +
                        "userID VARCHAR(50), " +
                        "oldBalance INT DEFAULT 0, " +
                        "newBalance INT DEFAULT 0, " +
                        "change INT DEFAULT 0, " +
                        "managedAt TIMESTAMP DEFAULT NOW(), " +
                        "FOREIGN KEY (userID) REFERENCES USERS(userID));";
                try {
                    statement.execute(createTableFunds);
                    System.out.println("Funds table created successfully.");
                }
                catch (SQLException e) {
                    System.out.println("Error creating Funds table: " + e.getMessage());
                }
                statement.close();
            }
            else {
                System.out.println("Database exists.");
                this.closeConnection(); // Closing previous connection
                conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/cms", "postgres", "12344");
                System.out.println("Database connected.");
            }
            statement0.close();
        }
        catch (SQLException e) {
            System.out.println("Connection failure!");
            e.printStackTrace();
        }
    }

    public void openConnection() {
        try {
            // Load the PostgreSQL driver
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/", "postgres", "12344");
            createDatabase();
        }
        catch (ClassNotFoundException e) {
            System.out.println("PostgreSQL JDBC Driver not found. Include it in your library path!");
            e.printStackTrace();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void closeConnection() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addUser(String userID, String fullName, String email, String address, String password, int age) {
        String checkQuery = "SELECT COUNT(*) FROM USERS WHERE userID = ? UNION ALL SELECT COUNT(*) FROM MANAGERS WHERE managerID = ?";
        String query = "INSERT INTO USERS (userID, fullName, email, address, password, age) VALUES (?, ?, ?, ?, ?, ?)";

        try (
                PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
                PreparedStatement stmt = conn.prepareStatement(query)
        ) {
            // Check if userID already exists in USERS or MANAGERS
            checkStmt.setString(1, userID);
            checkStmt.setString(2, userID);

            try (ResultSet rs = checkStmt.executeQuery()) {
                int totalCount = 0;
                while (rs.next()) {
                    totalCount += rs.getInt(1);
                }

                if (totalCount > 0) {
                    System.out.println("Error: UserID already exists in USERS or MANAGERS table.");
                    return;
                }
            }
            stmt.setString(1, userID);
            stmt.setString(2, fullName);
            stmt.setString(3, email);
            stmt.setString(4, address);
            stmt.setString(5, password);
            stmt.setInt(6, age);
            stmt.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addManager(String managerID, String fullName, String email, String address, String password) {
        String checkQuery = "SELECT COUNT(*) FROM USERS WHERE userID = ? UNION ALL SELECT COUNT(*) FROM MANAGERS WHERE managerID = ?";
        String query = "INSERT INTO MANAGERS (managerID, fullName, email, address, password) VALUES (?, ?, ?, ?, ?)";

        try (
                PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
                PreparedStatement stmt = conn.prepareStatement(query)
        ) {
            // Check if userID already exists in USERS or MANAGERS
            checkStmt.setString(1, managerID);
            checkStmt.setString(2, managerID);

            try (ResultSet rs = checkStmt.executeQuery()) {
                int totalCount = 0;
                while (rs.next()) {
                    totalCount += rs.getInt(1);
                }

                if (totalCount > 0) {
                    System.out.println("Error: UserID already exists in USERS or MANAGERS table.");
                    return;
                }
            }
            stmt.setString(1, managerID);
            stmt.setString(2, fullName);
            stmt.setString(3, email);
            stmt.setString(4, address);
            stmt.setString(5, password);
            stmt.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addGame(String gameName, int winMx) {
        String query = "INSERT INTO GAMES (gameName, winMx) VALUES (?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, gameName);
            stmt.setInt(2, winMx);
            stmt.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addReward(String rewardName, int pointsRequired, int stock, String path) {
        String query = "INSERT INTO REWARDS (rewardName, rewardPoints, rewardInStock, rewardImagePath) VALUES (?, ?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, rewardName);
            stmt.setInt(2, pointsRequired);
            stmt.setInt(3, stock);
            stmt.setString(4, path);

            stmt.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addRedeem(String userID, int rewardID) {
        String query = "INSERT INTO REDEEM (userID, rewardID) VALUES (?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, userID);
            stmt.setInt(2, rewardID);
            stmt.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addFund(String userID, int oldBalance, int newBalance, int change) {
        String query = "INSERT INTO FUNDS (userID, oldBalance, newBalance, change) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, userID);
            stmt.setInt(2, oldBalance);
            stmt.setInt(3, newBalance);
            stmt.setInt(4, change);
            stmt.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addMatch(String userID, int gameID, int betAmount, boolean result) {
        String query = "INSERT INTO MATCHES (userID, gameID, betAmount, result) VALUES (?, ?, ?, ?)";
        try (PreparedStatement preparedStatement = conn.prepareStatement(query)) {
            preparedStatement.setString(1, userID);
            preparedStatement.setInt(2, gameID);
            preparedStatement.setInt(3, betAmount);
            preparedStatement.setBoolean(4, result);
            preparedStatement.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean authenticateUser(String userID, String password, boolean isAdmin) {
        String query = isAdmin
                ? "SELECT 1 FROM MANAGERS WHERE managerID = ? AND password = ?"
                : "SELECT 1 FROM USERS WHERE userID = ? AND password = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, userID);
            pstmt.setString(2, password);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return true; // Authentication successful
                }
            }
        }
        catch (SQLException e) {
            System.out.println("Error during user/admin authentication: " + e.getMessage());
        }
        return false; // Authentication failed
    }

    public void getManagerDetails(String id, Manager manager) {
        String query = "SELECT * FROM MANAGERS WHERE managerID = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                manager.setId(rs.getString("managerID"));
                manager.setName(rs.getString("fullName"));
                manager.setEmail(rs.getString("email"));
                manager.setAddress(rs.getString("address"));
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void getUserDetails(String id, User user) {
        String query = "SELECT * FROM USERS WHERE userID = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                user.setId(rs.getString("userID"));
                user.setName(rs.getString("fullName"));
                user.setEmail(rs.getString("email"));
                user.setAddress(rs.getString("address"));
                user.setLoyaltyPoints(rs.getInt("loyaltyPoints"));
                user.setBalance(rs.getInt("balance"));
                user.setFlagged(rs.getBoolean("flagged"));
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateBalance(String userID, int newBalance) {
        String query = "UPDATE USERS SET balance = ? WHERE userID = ?";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, newBalance); // Set new balance
            stmt.setString(2, userID); // Set userID
            stmt.executeUpdate(); // Execute the update
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateLoyaltyPoints(String userID, int newLoyaltyPoints) {
        String query = "UPDATE USERS SET loyaltyPoints = ? WHERE userID = ?";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, newLoyaltyPoints); // Set new loyalty points
            stmt.setString(2, userID); // Set userID
            stmt.executeUpdate(); // Execute the update
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateFlaggedStatus(String userID, boolean isFlagged) {
        String query = "UPDATE USERS SET flagged = ? WHERE userID = ?";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setBoolean(1, isFlagged); // Set flagged status
            stmt.setString(2, userID); // Set userID
            stmt.executeUpdate(); // Execute the update
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<String> getAllUserIds() {
        String query = "SELECT userID FROM USERS"; // SQL query to get all user IDs

        try (PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            // To store the user IDs in an array
            List<String> userIdsList = new ArrayList<>();
            // Loop through the result set and add each user ID to the list
            while (rs.next()) {
                userIdsList.add(rs.getString("userID"));
            }
            return userIdsList;
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return new ArrayList<>(); // If an exception occurs or no users found
    }

//    public List<Reward> getAllRewards() {
//        String query = "SELECT * FROM REWARDS";
//
//        try (PreparedStatement stmt = conn.prepareStatement(query);
//             ResultSet rs = stmt.executeQuery()) {
//            // List to store rewards temporarily
//            List<Reward> rewardsList = new ArrayList<>();
//            while (rs.next()) {
//                // Create a new Reward object and populate its attributes
//                Reward reward = new Reward();
//                reward.setRewardID(rs.getInt("rewardID"));
//                reward.setRewardName(rs.getString("rewardName"));
//                reward.setRewardPoints(rs.getInt("rewardPoints"));
//                reward.setRewardInStock(rs.getInt("rewardInStock"));
//                reward.setRewardImagePath(rs.getString("rewardImagePath"));
//                // Add to the rewards list
//                rewardsList.add(reward);
//            }
//            return rewardsList;
//
//        }
//        catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return new ArrayList<>(); // In case of error or no rewards
//    }
//
    public List<Game> getAllGames() {
        String query = "SELECT * FROM GAMES";

        try (PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            // List to store games temporarily
            List<Game> gamesList = new ArrayList<>();
            while (rs.next()) {
                Game game;
                // Create a new Game object and populate its attributes
                if (rs.getInt("winMx") > 3) {
                    game = new HighRiskGame(rs.getInt("gameID"), rs.getString("gameName"), rs.getInt("winMx"));
                }
                else {
                    game = new NormalGame(rs.getInt("gameID"), rs.getString("gameName"), rs.getInt("winMx"));
                }
                // Add to the games list
                gamesList.add(game);
            }
            return gamesList;
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return new ArrayList<>(); // In case of error or no games
    }
}
