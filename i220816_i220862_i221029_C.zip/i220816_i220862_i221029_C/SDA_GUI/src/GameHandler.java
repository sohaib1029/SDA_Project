import java.util.List;
public class GameHandler {
    //private RewardHandler rewardHandler;
    private List<Game> games;

    public GameHandler() {
        //this.rewardHandler = new RewardHandler();
        games = DBHandler.getInstance().getAllGames();
    }

    public String[] getGameNames() {
        String[] gameNames = new String[games.size()];
        for (int i = 0; i < games.size(); i++) {
            gameNames[i] = games.get(i).getName();
        }
        return gameNames;
    }

    public int placeBetAndPlay(int bet, int gameIndex) {
        if (User.getInstance().getFlagged()) {
            System.out.println("Access denied: Player is flagged for suspicious behavior.");
            return 1;
        }
        if (User.getInstance().getBalance() < bet) {
            System.out.println("Insufficient balance. Please top up your account.");
            return 2;
        }
        // Deduct cost to play
        User.getInstance().updateBalance(User.getInstance().getBalance() - bet);
        //rewardHandler.calculateAndAssignRewards(bet);
        // Simulate game outcome
        boolean hasWon = games.get(gameIndex).play();
        if (hasWon) {
            int winnings = bet * games.get(gameIndex).getPayoutMultiplier();
            User.getInstance().updateBalance(User.getInstance().getBalance() + winnings);
            DBHandler.getInstance().addMatch(User.getInstance().getId(), games.get(gameIndex).getId(), bet, true);
            return 3;
        }
        else {
            DBHandler.getInstance().addMatch(User.getInstance().getId(), games.get(gameIndex).getId(), bet, false);
            System.out.print("You lost. Better luck next time! New balance: $" + User.getInstance().getBalance());
            return 4;
        }
    }
}
