import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import java.awt.*;
import java.awt.event.*;

public class ManagementScreen {
    JFrame frame;
    Border defaultBtnBorder;
    Border hoverBtnBorder;
    MouseAdapter buttonMouseListener;
    FocusAdapter buttonFocusListener;

    ManagementScreen() {
        defaultBtnBorder = new EtchedBorder(1, Color.DARK_GRAY, Color.DARK_GRAY);
        hoverBtnBorder = new EtchedBorder(1, Color.GRAY, Color.LIGHT_GRAY);
        // Create common mouse and focus listeners
        buttonMouseListener = UIUtils.createButtonMouseListener(defaultBtnBorder, hoverBtnBorder);
        buttonFocusListener = UIUtils.createButtonFocusListener(defaultBtnBorder, hoverBtnBorder);

        frame = UIUtils.createFrame("Casino Management System", 275, 50, 800, 600, true);
        JLayeredPane mainPane = UIUtils.createPane(0, 0, 800, 600);
        JLabel backgroundImageLabel = UIUtils.createLabel("", 0, 0, 800, 600, null, null, null, null, 0);
        UIUtils.imageIcon(backgroundImageLabel, "C:\\Users\\Students\\Downloads\\resources_sda_project\\background_800_600_1.png");
        UIUtils.imageIcon(frame, "C:\\Users\\Students\\Downloads\\resources_sda_project\\casino_logo.jpg");

        JButton regBtn = UIUtils.createButton("Register User", 100, 300, 150, 25, new Font("Comic Sans", Font.ITALIC, 22), Color.WHITE, false, defaultBtnBorder);
        JButton reportBtn = UIUtils.createButton("Report", 100, 350, 150, 25, new Font("Comic Sans", Font.ITALIC, 22), Color.WHITE, false, defaultBtnBorder);
        JButton flagBtn = UIUtils.createButton("Flag User", 100, 400, 150, 25, new Font("Comic Sans", Font.ITALIC, 22), Color.WHITE, false, defaultBtnBorder);
        JButton outBtn = UIUtils.createButton("Log Out", 100, 450, 150, 30, new Font("Comic Sans", Font.ITALIC, 22), Color.WHITE, false, defaultBtnBorder);

        // Add listeners for all buttons
        addButtonListeners(regBtn, regBtn.getText());
        addButtonListeners(reportBtn, reportBtn.getText());
        addButtonListeners(flagBtn, flagBtn.getText());
        addButtonListeners(outBtn, outBtn.getText());

        JLabel welcomeMessage = UIUtils.createLabel("Welcome, " + Manager.getInstance().getId(), 620, 5, 200, 100, new Font("Comic Sans", Font.ITALIC, 17), Color.WHITE, null, null, 2);
        UIUtils.imageIcon(welcomeMessage, "C:\\Users\\Students\\Downloads\\resources_sda_project\\user_icon_best.png");
        welcomeMessage.setHorizontalTextPosition(JLabel.CENTER);
        welcomeMessage.setVerticalTextPosition(JLabel.BOTTOM);

        mainPane.add(backgroundImageLabel, JLayeredPane.DEFAULT_LAYER);
        mainPane.add(regBtn, JLayeredPane.PALETTE_LAYER);
        mainPane.add(reportBtn, JLayeredPane.PALETTE_LAYER);
        mainPane.add(flagBtn, JLayeredPane.PALETTE_LAYER);
        mainPane.add(outBtn, JLayeredPane.PALETTE_LAYER);
        mainPane.add(welcomeMessage, JLayeredPane.PALETTE_LAYER);

        frame.setContentPane(mainPane);
    }

    // Generic method to add mouse, focus, and action listeners to buttons
    private void addButtonListeners(JButton button, String buttonLabel) {
        button.addActionListener(createButtonActionListener(buttonLabel));
        button.addMouseListener(buttonMouseListener);
        button.addFocusListener(buttonFocusListener);
    }

    // Method to create button-specific action listeners
    private ActionListener createButtonActionListener(String buttonLabel) {
        return new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton source = (JButton) e.getSource();
                source.setContentAreaFilled(true);
                source.setBackground(Color.GRAY);

                // Use a timer to revert the appearance after a short delay (delay of 100 ms i.e., click and release)
                Timer timer = new Timer(100, event -> {
                    source.setBackground(UIManager.getColor("Button.background"));
                    source.setContentAreaFilled(false);
                });
                timer.setRepeats(false);
                timer.start();
                openNextWindow(buttonLabel);
//                switch (buttonLabel) {
//                    case "RegisterScreen User":
//                        System.out.println("RegisterScreen button clicked!");
//                        openNextWindow(buttonLabel); // Open the next window
//                        break;
//                    case "Report":
//                        System.out.println("Report button clicked!");
//                        openNextWindow(buttonLabel); // Open the next window
//                        break;
//                    case "Log Out":
//                        System.out.println("Log Out button clicked!");
//                        openNextWindow(buttonLabel); // Open the next window
//                        break;
//                }
            }
        };
    }

    private void openNextWindow(String buttonLabel) {
        // Use the factory to create the appropriate screen
        Object nextScreen = ScreenFactory.createScreen(buttonLabel, this.frame);

        if (nextScreen instanceof LoginScreen) {
            User.resetInstance();
            frame.dispose(); // Close the current frame only for LoginScreen
        }
        else {
            frame.setVisible(false); // Hide the frame for other screens
        }
    }
}
