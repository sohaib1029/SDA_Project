import javax.swing.*;

public class ScreenFactory {
    public static Object createScreen(String screenType, JFrame parentFrame) {
        switch (screenType) {
            case "User":
                return new UserScreen();
            case "Management":
                return new ManagementScreen();
            case "Register User":
                return new RegisterScreen(parentFrame);
            case "Report":
                return new LoginScreen();
            case "Flag User":
                return new FlagScreen(parentFrame);
            case "Play":
                return new GamesAndBetScreen(parentFrame);
            case "Funds":
                return new DepositAndWithdrawScreen(parentFrame);
            case "Redeem":
                return new RedeemReward(parentFrame);
            case "Log Out":
                return new LoginScreen();
            default:
                throw new IllegalArgumentException("Unknown screen type: " + screenType);
        }
    }
}
