import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import java.awt.*;
import java.awt.event.*;

public class RegisterScreen {
    JFrame frame;
    JFrame prevFrame;
    JTextField fullNameText, userNameText, addressText, emailText, ageText;
    JPasswordField passText;
    Border defaultBtnBorder;
    Border hoverBtnBorder;
    MouseAdapter buttonMouseListener;
    FocusAdapter buttonFocusListener;
    private DBFacade dbFacade;

    RegisterScreen(JFrame prevFrame) {
        dbFacade = new DBFacade();
        this.prevFrame = prevFrame;
        defaultBtnBorder = new EtchedBorder(1, Color.DARK_GRAY, Color.LIGHT_GRAY);
        hoverBtnBorder = new EtchedBorder(1, Color.GRAY, Color.DARK_GRAY);
        // Create common mouse and focus listeners
        buttonMouseListener = UIUtils.createButtonMouseListener(defaultBtnBorder, hoverBtnBorder);
        buttonFocusListener = UIUtils.createButtonFocusListener(defaultBtnBorder, hoverBtnBorder);

        frame = UIUtils.createFrame("Casino Management System", 275, 50, 800, 600, true);
        JLayeredPane mainPane = UIUtils.createPane(0, 0, 800, 600);
        JLabel backgroundImageLabel = UIUtils.createLabel("", 0, 0, 800, 600, null, null, null, null, 0);
        UIUtils.imageIcon(backgroundImageLabel, "C:\\Users\\Students\\Downloads\\resources_sda_project\\bckg_login.png");
        UIUtils.imageIcon(frame, "C:\\Users\\Students\\Downloads\\resources_sda_project\\casino_logo.jpg");

        JLabel registerLabel = UIUtils.createLabel("Register New Account", 70, 100, 500, 50, new Font("Comic Sans", Font.BOLD, 25), Color.WHITE, null, null, 2);
        JLabel fullNameLabel = UIUtils.createLabel("Full Name:", 70, 175, 150, 40, new Font("Comic Sans", Font.ITALIC, 22), Color.WHITE, null, null, 2);
        JLabel userNameLabel = UIUtils.createLabel("Username:", 70, 225, 150, 40, new Font("Comic Sans", Font.ITALIC, 22), Color.WHITE, null, null, 2);
        JLabel emailLabel = UIUtils.createLabel("Email:", 70, 275, 150, 40, new Font("Comic Sans", Font.ITALIC, 22), Color.WHITE, null, null, 2);
        JLabel addressLabel = UIUtils.createLabel("Address:", 70, 325, 150, 40, new Font("Comic Sans", Font.ITALIC, 22), Color.WHITE, null, null, 2);
        JLabel ageLabel = UIUtils.createLabel("Age:", 70, 375, 150, 40, new Font("Comic Sans", Font.ITALIC, 22), Color.WHITE, null, null, 2);
        JLabel passLabel = UIUtils.createLabel("Password:", 70, 425, 150, 40, new Font("Comic Sans", Font.ITALIC, 22), Color.WHITE, null, null, 2);

        fullNameText = UIUtils.createTextField(230, 180, 200, 30, new Font("Consolas", Font.PLAIN, 22), Color.WHITE, Color.GRAY, Color.WHITE, "Enter Full Name", new Insets(5, 5, -1, 0));
        userNameText = UIUtils.createTextField(230, 230, 200, 30, new Font("Consolas", Font.PLAIN, 22), Color.WHITE, Color.GRAY, Color.WHITE, "Enter Username", new Insets(5, 5, -1, 0));
        emailText = UIUtils.createTextField(230, 280, 200, 30, new Font("Consolas", Font.PLAIN, 22), Color.WHITE, Color.GRAY, Color.WHITE, "Enter Email", new Insets(5, 5, -1, 0));
        addressText = UIUtils.createTextField(230, 330, 200, 30, new Font("Consolas", Font.PLAIN, 22), Color.WHITE, Color.GRAY, Color.WHITE, "Enter Address", new Insets(5, 5, -1, 0));
        ageText = UIUtils.createTextField(230, 380, 200, 30, new Font("Consolas", Font.PLAIN, 22), Color.WHITE, Color.GRAY, Color.WHITE, "Enter Password", new Insets(5, 5, -1, 0));
        passText = UIUtils.createPassField(230, 430, 200, 30, new Font("Consolas", Font.PLAIN, 22), Color.WHITE, Color.GRAY, Color.WHITE, "Enter Password", new Insets(5, 5, -1, 0));

        JButton backBtn = UIUtils.createButton("", 15, 15, 50, 50, null, null, false, defaultBtnBorder);
        UIUtils.imageIcon(backBtn, "C:\\Users\\Students\\Downloads\\resources_sda_project\\backBtn.png");
        JButton registerBtn = UIUtils.createButton("Register", 200, 500, 130, 30, new Font("Comic Sans", Font.BOLD, 22), Color.WHITE, false, defaultBtnBorder);
        JButton showBtn = UIUtils.createButton("Show", 450, 430, 50, 30, new Font("Comic Sans", Font.PLAIN, 14), Color.WHITE, false, defaultBtnBorder);

        addButtonListeners(backBtn, "Back");
        addButtonListeners(registerBtn, "Register");
        addButtonListeners(showBtn, "Show");

        mainPane.add(backgroundImageLabel, JLayeredPane.DEFAULT_LAYER);
        mainPane.add(backBtn, JLayeredPane.PALETTE_LAYER);
        mainPane.add(registerBtn, JLayeredPane.PALETTE_LAYER);
        mainPane.add(showBtn, JLayeredPane.PALETTE_LAYER);
        mainPane.add(registerLabel, JLayeredPane.PALETTE_LAYER);
        mainPane.add(fullNameLabel, JLayeredPane.PALETTE_LAYER);
        mainPane.add(userNameLabel, JLayeredPane.PALETTE_LAYER);
        mainPane.add(passLabel, JLayeredPane.PALETTE_LAYER);
        mainPane.add(ageLabel, JLayeredPane.PALETTE_LAYER);
        mainPane.add(addressLabel, JLayeredPane.PALETTE_LAYER);
        mainPane.add(emailLabel, JLayeredPane.PALETTE_LAYER);
        mainPane.add(fullNameText, JLayeredPane.PALETTE_LAYER);
        mainPane.add(userNameText, JLayeredPane.PALETTE_LAYER);
        mainPane.add(passText, JLayeredPane.PALETTE_LAYER);
        mainPane.add(ageText, JLayeredPane.PALETTE_LAYER);
        mainPane.add(addressText, JLayeredPane.PALETTE_LAYER);
        mainPane.add(emailText, JLayeredPane.PALETTE_LAYER);

        frame.setContentPane(mainPane);
    }

    // Generic method to add mouse, focus, and action listeners to buttons
    private void addButtonListeners(JButton button, String buttonLabel) {
        button.addActionListener(createButtonActionListener(buttonLabel));
        button.addMouseListener(buttonMouseListener);
        button.addFocusListener(buttonFocusListener);
    }

    // Method to create button-specific action listeners
    private ActionListener createButtonActionListener(String buttonLabel) {
        return new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton source = (JButton) e.getSource();
                switch (buttonLabel) {
                    case "Back":
                        source.setContentAreaFilled(true);
                        source.setBackground(Color.GRAY);

                        // Use a timer to revert the appearance after a short delay (delay of 100 ms i.e., click and release)
                        Timer timer = new Timer(100, event -> {
                            source.setBackground(UIManager.getColor("Button.background"));
                            source.setContentAreaFilled(false);
                        });
                        timer.setRepeats(false);
                        timer.start();
                        System.out.println("Back button clicked!");
                        frame.dispose();
                        prevFrame.setVisible(true);
                        break;
                    case "Show":
                        source.setContentAreaFilled(true);
                        source.setBackground(Color.DARK_GRAY);

                        // Use a timer to revert the appearance after a short delay (delay of 100 ms i.e., click and release)
                        timer = new Timer(100, event -> {
                            source.setBackground(UIManager.getColor("Button.background"));
                            source.setContentAreaFilled(false);
                        });
                        timer.setRepeats(false);
                        timer.start();
                        if (passText.getEchoChar() == '●') {
                            passText.setEchoChar((char) 0); // Reveal password
                            source.setText("Hide");
                        }
                        else {
                            passText.setEchoChar('●'); // Hide password
                            source.setText("Show");
                        }
                        break;
                    case "Register":
                        source.setContentAreaFilled(true);
                        source.setBackground(Color.GRAY);

                        // Use a timer to revert the appearance after a short delay (delay of 100 ms i.e., click and release)
                        timer = new Timer(100, event -> {
                            source.setBackground(UIManager.getColor("Button.background"));
                            source.setContentAreaFilled(false);
                        });
                        timer.setRepeats(false);
                        timer.start();

                        String fullName = fullNameText.getText().trim();
                        String username = userNameText.getText().trim();
                        String password = passText.getText().trim();
                        String address = addressText.getText().trim();
                        String email = emailText.getText().trim();
                        String age = ageText.getText().trim();

                        // Check if all fields are filled
                        if (fullName.isEmpty() || username.isEmpty() || password.isEmpty() || address.isEmpty() || email.isEmpty() || age.isEmpty()) {
                            JOptionPane.showMessageDialog(
                                    frame,
                                    "Please fill in all fields!",
                                    "Missing Details",
                                    JOptionPane.WARNING_MESSAGE
                            );
                        }
                        else {
                            boolean check = Manager.getInstance().registerUser(username, fullName, email, address, password, Integer.parseInt(age));
                            if (check) {
                                JOptionPane.showMessageDialog(
                                        frame,
                                        "Registration Successful!",
                                        "Success",
                                        JOptionPane.INFORMATION_MESSAGE
                                );
                            }
                            else {
                                JOptionPane.showMessageDialog(
                                        frame,
                                        "Cannot register under age players!",
                                        "Under Age",
                                        JOptionPane.WARNING_MESSAGE
                                );
                            }
                            // Clear all text fields
                            fullNameText.setText("");
                            userNameText.setText("");
                            passText.setText("");
                            addressText.setText("");
                            emailText.setText("");
                            ageText.setText("");
                        }
                        break;
                }
            }
        };
    }
}
