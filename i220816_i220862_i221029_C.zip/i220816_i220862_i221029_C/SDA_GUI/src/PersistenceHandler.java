import java.util.List;

public abstract class PersistenceHandler {
    public abstract boolean authenticateUser(String userID, String password, boolean isAdmin);
    public abstract void addUser(String userID, String fullName, String email, String address, String password, int age);
    public abstract void addManager(String managerID, String fullName, String email, String address, String password);
    public abstract void addGame(String gameName, int winMx);
    public abstract void addReward(String rewardName, int pointsRequired, int stock, String path);
    public abstract void addRedeem(String userID, int rewardID);
    public abstract void addFund(String userID, int oldBalance, int newBalance, int change);
    public abstract void addMatch(String userID, int gameID, int betAmount, boolean result);
    public abstract void getUserDetails(String id, User user);
    public abstract void getManagerDetails(String id, Manager manager);
//    public abstract List<Reward> getAllRewards();
//    public abstract List<Game> getAllGames();
    public abstract void updateBalance(String userID, int newBalance);
    public abstract void updateLoyaltyPoints(String userID, int newLoyaltyPoints);
    public abstract void updateFlaggedStatus(String userID, boolean isFlagged);
    public abstract List<String> getAllUserIds();
}