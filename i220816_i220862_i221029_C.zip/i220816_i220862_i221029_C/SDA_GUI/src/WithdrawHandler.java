public class WithdrawHandler {
    public int withdraw(int amount) {
        if (User.getInstance().getFlagged()) {
            System.out.println("You have been flagged by the system and cannot perform this operation. Kindly contact the admin for further explanation.");
            return 1;
        }
        if (amount <= 0) {
            System.out.println("Withdrawal failed: Amount must be greater than zero.");
            return 2;
        }
        if (User.getInstance().getBalance() < amount) {
            System.out.print("Withdrawal failed: Insufficient funds.");
            return 3;
        }
        int oldBalance = User.getInstance().getBalance();
        int newBalance = User.getInstance().getBalance() - amount;
        DBHandler.getInstance().addFund(User.getInstance().getId(), oldBalance, newBalance, newBalance - oldBalance);
        User.getInstance().setBalance(newBalance);
        System.out.println("Withdrawal successful! New balance: $" + User.getInstance().getBalance());
        return 4;
    }
}
