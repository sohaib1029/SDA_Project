import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import java.awt.*;
import java.awt.event.*;

public class RedeemReward {
    JFrame frame;
    JFrame prevFrame;
    JDialog tempDialog;
    Border defaultBtnBorder;
    Border hoverBtnBorder;
    MouseAdapter buttonMouseListener;
    FocusAdapter buttonFocusListener;

    RedeemReward(JFrame prevFrame) {
        this.prevFrame = prevFrame;
        defaultBtnBorder = new EtchedBorder(1, Color.DARK_GRAY, Color.DARK_GRAY);
        hoverBtnBorder = new EtchedBorder(1, Color.GRAY, Color.LIGHT_GRAY);
        // Create common mouse and focus listeners
        buttonMouseListener = UIUtils.createButtonMouseListener(defaultBtnBorder, hoverBtnBorder);
        buttonFocusListener = UIUtils.createButtonFocusListener(defaultBtnBorder, hoverBtnBorder);

        frame = UIUtils.createFrame("Casino Management System", 275, 50, 800, 600, true);
        JLayeredPane mainPane = UIUtils.createPane(0, 0, 800, 600);
        JLabel backgroundImageLabel = UIUtils.createLabel("", 0, 0, 800, 600, null, null,  null, null, 0);
        UIUtils.imageIcon(backgroundImageLabel, "C:\\Users\\Students\\Downloads\\resources_sda_project\\background_800_600_1.png");
        UIUtils.imageIcon(frame, "C:\\Users\\Students\\Downloads\\resources_sda_project\\casino_logo.jpg");

        JPanel rewardPanel = UIUtils.createPanel(70, 100, 650, 400, new Color(0, 0, 0, 100), false, new GridLayout(2, 3, 50, 50));

        JButton backBtn = UIUtils.createButton("", 15, 15, 50, 50, null, null, false, defaultBtnBorder);
        UIUtils.imageIcon(backBtn, "C:\\Users\\Students\\Downloads\\resources_sda_project\\backBtn.png");
        JButton rewardOne = UIUtils.createRewardButton(false, defaultBtnBorder);
        UIUtils.imageIcon(rewardOne, "C:\\Users\\Students\\Downloads\\resources_sda_project\\1st.png");
        JButton rewardTwo = UIUtils.createRewardButton(false, defaultBtnBorder);
        UIUtils.imageIcon(rewardTwo, "C:\\Users\\Students\\Downloads\\resources_sda_project\\2nd.png");
        JButton rewardThree = UIUtils.createRewardButton(false, defaultBtnBorder);
        UIUtils.imageIcon(rewardThree, "C:\\Users\\Students\\Downloads\\resources_sda_project\\3rd.png");
        JButton rewardFour = UIUtils.createRewardButton(false, defaultBtnBorder);
        UIUtils.imageIcon(rewardFour, "C:\\Users\\Students\\Downloads\\resources_sda_project\\4th.png");
        JButton rewardFive = UIUtils.createRewardButton(false, defaultBtnBorder);
        UIUtils.imageIcon(rewardFive, "C:\\Users\\Students\\Downloads\\resources_sda_project\\5th.png");
        JButton rewardSix = UIUtils.createRewardButton(false, defaultBtnBorder);
        UIUtils.imageIcon(rewardSix, "C:\\Users\\Students\\Downloads\\resources_sda_project\\6th.png");

        // Add listeners for all buttons
        addButtonListeners(backBtn,"Back");
        addButtonListeners(rewardOne, "1");
        addButtonListeners(rewardTwo, "2");
        addButtonListeners(rewardThree, "3");
        addButtonListeners(rewardFour, "4");
        addButtonListeners(rewardFive, "5");
        addButtonListeners(rewardSix, "6");

        JLabel loyaltyPoints = UIUtils.createLabel("Loyalty Points: " + User.getInstance().getLoyaltyPoints(), 252, 520, 150, 35, new Font("Comic Sans", Font.ITALIC, 16), Color.WHITE, null, null, 2);
        JLabel funds = UIUtils.createLabel("Funds: " + User.getInstance().getBalance(), 452, 520, 150, 35, new Font("Comic Sans", Font.ITALIC, 16), Color.WHITE, null, null, 2);

        rewardPanel.add(rewardOne);
        rewardPanel.add(rewardTwo);
        rewardPanel.add(rewardThree);
        rewardPanel.add(rewardFour);
        rewardPanel.add(rewardFive);
        rewardPanel.add(rewardSix);
        mainPane.add(backgroundImageLabel, JLayeredPane.DEFAULT_LAYER);
        mainPane.add(backBtn, JLayeredPane.PALETTE_LAYER);
        mainPane.add(rewardPanel, JLayeredPane.PALETTE_LAYER);
        mainPane.add(loyaltyPoints, JLayeredPane.PALETTE_LAYER);
        mainPane.add(funds, JLayeredPane.PALETTE_LAYER);
        frame.setContentPane(mainPane);
    }

    // Generic method to add mouse, focus, and action listeners to buttons
    private void addButtonListeners(JButton button, String buttonLabel) {
        button.addActionListener(createButtonActionListener(buttonLabel));
        button.addMouseListener(buttonMouseListener);
        button.addFocusListener(buttonFocusListener);
    }

    // Method to create button-specific action listeners
    private ActionListener createButtonActionListener(String buttonLabel) {
        return new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton source = (JButton) e.getSource();
                source.setContentAreaFilled(true);
                source.setBackground(Color.GRAY);

                // Use a timer to revert the appearance after a short delay (delay of 100 ms i.e., click and release)
                Timer timer = new Timer(100, event -> {
                    source.setBackground(UIManager.getColor("Button.background"));
                    source.setContentAreaFilled(false);
                });
                timer.setRepeats(false);
                timer.start();
                switch (buttonLabel) {
                    case "Back":
                        System.out.println("Back button clicked!");
                        frame.dispose();
                        prevFrame.setVisible(true);
                        break;
                    case "1":
                        System.out.println("1st button clicked!");
                        tempDialog = UIUtils.createDialog(frame, "Casino Management System", 400, 300); // Create JDialog instead of JFrame
                        UIUtils.imageIcon(tempDialog, "C:\\Users\\Students\\Downloads\\resources_sda_project\\casino_logo.jpg");
                        JLabel reqPointsLabel = UIUtils.createLabel("xxx Loyalty Points Required", 65, 80, 250, 35, new Font("Comic Sans", Font.PLAIN, 20), Color.WHITE, null, null, 0);
                        JButton redeemBtn = UIUtils.createButton("Redeem", 145, 150, 100, 35, new Font("Comic Sans", Font.ITALIC, 18), Color.WHITE, false, defaultBtnBorder);
                        addButtonListeners(redeemBtn,"Redeem");
                        tempDialog.add(redeemBtn, BorderLayout.CENTER);
                        tempDialog.add(reqPointsLabel, BorderLayout.CENTER);
                        tempDialog.setVisible(true);
                        break;
                    case "Redeem":
                        // Compare against users loyalty points and decide to get him the reward or not
                        // manage loyalty points accordingly
                        System.out.println("Redeem button clicked!");
                        tempDialog.dispose();
                        break;
                }
            }
        };
    }
}