import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.MouseAdapter;

public class GamesAndBetScreen {
    JFrame frame;
    JFrame prevFrame;
    JComboBox gamesComboBox;
    JTextField betAmountText;
    Border defaultBtnBorder;
    Border hoverBtnBorder;
    MouseAdapter buttonMouseListener;
    FocusAdapter buttonFocusListener;
    GameHandler playHandler;

    GamesAndBetScreen(JFrame prevFrame) {
        playHandler = new GameHandler();
        this.prevFrame = prevFrame;
        defaultBtnBorder = new EtchedBorder(1, Color.DARK_GRAY, Color.DARK_GRAY);
        hoverBtnBorder = new EtchedBorder(1, Color.GRAY, Color.LIGHT_GRAY);
        // Create common mouse and focus listeners
        buttonMouseListener = UIUtils.createButtonMouseListener(defaultBtnBorder, hoverBtnBorder);
        buttonFocusListener = UIUtils.createButtonFocusListener(defaultBtnBorder, hoverBtnBorder);

        frame = UIUtils.createFrame("Casino Management System", 275, 50, 800, 600, true);
        JLayeredPane mainPane = UIUtils.createPane(0, 0, 800, 600);
        JLabel backgroundImageLabel = UIUtils.createLabel("", 0, 0, 800, 600, null, null,  null, null, 0);
        UIUtils.imageIcon(backgroundImageLabel, "C:\\Users\\Students\\Downloads\\resources_sda_project\\background_800_600_1.png");
        UIUtils.imageIcon(frame, "C:\\Users\\Students\\Downloads\\resources_sda_project\\casino_logo.jpg");

        // Add Combo Box with Casino Games
        String[] games = playHandler.getGameNames();
        gamesComboBox = UIUtils.createComboBox(games, 300, 215, 200, 30, new Font("Comic Sans", Font.BOLD, 16), "Select Game");
        gamesComboBox.setSelectedIndex(-1);

        JButton backBtn = UIUtils.createButton("", 15, 15, 50, 50, null, null, false, defaultBtnBorder);
        UIUtils.imageIcon(backBtn, "C:\\Users\\Students\\Downloads\\resources_sda_project\\backBtn.png");
        JButton placeBetBtn = UIUtils.createButton("Place Bet", 330, 450, 130, 30, new Font("Comic Sans", Font.BOLD, 22), Color.WHITE, false, defaultBtnBorder);

        // Add listeners for all buttons
        addButtonListeners(backBtn, "Back");
        addButtonListeners(placeBetBtn, "Bet");

        JLabel betAmount = UIUtils.createLabel("Bet Amount:", 220, 300, 130, 30, new Font("Comic Sans", Font.ITALIC, 22), Color.WHITE, null, null, 2);
        JLabel gamesLabel = UIUtils.createLabel("Available Games", 300, 175, 200, 35, new Font("Comic Sans", Font.ITALIC, 22), Color.WHITE, null, hoverBtnBorder, 0);
        JLabel loyaltyPoints = UIUtils.createLabel("Loyalty Points: " + User.getInstance().getLoyaltyPoints(), 600, 480, 150, 35, new Font("Comic Sans", Font.ITALIC, 16), Color.WHITE, null, null, 2);
        JLabel funds = UIUtils.createLabel("Funds: " + User.getInstance().getBalance(), 600, 505, 150, 35, new Font("Comic Sans", Font.ITALIC, 16), Color.WHITE, null, null, 2);

        betAmountText = UIUtils.createTextField(350, 300, 200, 30, new Font("Consolas", Font.PLAIN, 22), Color.BLACK, Color.LIGHT_GRAY, Color.BLACK, "Enter Bet Amount", new Insets(5, 5, -1, 0));

        mainPane.add(backgroundImageLabel, JLayeredPane.DEFAULT_LAYER);
        mainPane.add(backBtn, JLayeredPane.PALETTE_LAYER);
        mainPane.add(placeBetBtn, JLayeredPane.PALETTE_LAYER);
        mainPane.add(gamesComboBox, JLayeredPane.PALETTE_LAYER);
        mainPane.add(betAmount, JLayeredPane.PALETTE_LAYER);
        mainPane.add(gamesLabel, JLayeredPane.PALETTE_LAYER);
        mainPane.add(loyaltyPoints, JLayeredPane.PALETTE_LAYER);
        mainPane.add(funds, JLayeredPane.PALETTE_LAYER);
        mainPane.add(betAmountText, JLayeredPane.PALETTE_LAYER);
        frame.setContentPane(mainPane);
    }

    // Generic method to add mouse, focus, and action listeners to buttons
    private void addButtonListeners(JButton button, String buttonLabel) {
        button.addActionListener(createButtonActionListener(buttonLabel));
        button.addMouseListener(buttonMouseListener);
        button.addFocusListener(buttonFocusListener);
    }

    // Method to create button-specific action listeners
    private ActionListener createButtonActionListener(String buttonLabel) {
        return new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton source = (JButton) e.getSource();
                source.setContentAreaFilled(true);
                source.setBackground(Color.GRAY);

                // Use a timer to revert the appearance after a short delay (delay of 100 ms i.e., click and release)
                Timer timer = new Timer(100, event -> {
                    source.setBackground(UIManager.getColor("Button.background"));
                    source.setContentAreaFilled(false);
                });
                timer.setRepeats(false);
                timer.start();
                switch (buttonLabel) {
                    case "Back":
                        System.out.println("Back button clicked!");
                        frame.dispose();
                        prevFrame.setVisible(true);
                        break;
                    case "Bet":
                        System.out.println("Bet button clicked!");
                        String selectedGame = (String) gamesComboBox.getSelectedItem();
                        if (selectedGame != null) {
                            String betAmount = betAmountText.getText().trim();
                            int result = playHandler.placeBetAndPlay(Integer.parseInt(betAmount), gamesComboBox.getSelectedIndex());
                            if (result == 3) {
                                JOptionPane.showMessageDialog(
                                        frame,
                                        "Congratulations! You won! New balance: $" + User.getInstance().getBalance(),
                                        "Game Result",
                                        JOptionPane.INFORMATION_MESSAGE
                                );
                            }
                            else if (result == 1) {
                                JOptionPane.showMessageDialog(
                                        frame,
                                        "Access denied: You are flagged for suspicious behavior.",
                                        "User Flagged",
                                        JOptionPane.ERROR_MESSAGE
                                );
                            }
                            else if (result == 2) {
                                JOptionPane.showMessageDialog(
                                        frame,
                                        "Insufficient balance. Please top up your account.",
                                        "Insufficient Balance",
                                        JOptionPane.ERROR_MESSAGE
                                );
                            }
                            else {
                                JOptionPane.showMessageDialog(
                                        frame,
                                        "You lost. Better luck next time! New balance: $" + User.getInstance().getBalance(),
                                        "Game Result",
                                        JOptionPane.INFORMATION_MESSAGE
                                );
                            }
                            gamesComboBox.setSelectedIndex(-1);
                            betAmountText.setText("");
                        }
                        else {
                            JOptionPane.showMessageDialog(
                                    frame,
                                    "No game selected.",
                                    "Error",
                                    JOptionPane.ERROR_MESSAGE
                            );
                        }
                        break;
                }
            }
        };
    }
}
