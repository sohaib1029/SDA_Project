public class TransactionManager {
    private DepositHandler depositHandler;
    private WithdrawHandler withdrawHandler;

    TransactionManager() {
        withdrawHandler = new WithdrawHandler();
        depositHandler = new DepositHandler();
    }

    // Handle deposits with payment method validation
    public int handleDeposit(int amount) {
        return depositHandler.deposit(amount);
    }

    // Handle withdrawals with verification
    public int handleWithdraw(int amount) {
        return withdrawHandler.withdraw(amount);
    }
}