public class Main {
    // One thing left in redeem reward that is, when the redeem button clicked in dialog, i don't know which reward button was
    // clicked initially to store its details in db
    // Also report page on management screen left
    // And Flag screen may be implemented later (to flag users)
    // Functions of getImagePathOfAllRewards and getAllGameNames will be in Reward and Game classes
    // Can make these classes singleton (choice on me)
    // Can have add games, rewards functionality in management screen
    public static void main(String[] args) {
        DBHandler dbHandler = DBHandler.getInstance();
        dbHandler.addUser("msbm290", "Muhammad Sohaib", "msbm@gmail.com", "DHA Phase 1", "123Hehe", 18);
        dbHandler.addManager("rhbAuto", "Rihab", "rihab@gmail.com", "DHA Phase 2", "he!He");
        dbHandler.addUser("rhbAuto", "Rihab", "rihab@gmail.com", "DHA Phase 2", "he!He", 20);
        dbHandler.addGame("Blackjack", 2);
        dbHandler.addGame("Slots", 3);
        dbHandler.addGame("Roulette", 5);
        dbHandler.addReward("Car", 1000, 5, "C:\\Users\\Students\\Downloads\\resources_sda_project\\1st.png");
        dbHandler.addReward("Guitar", 500, 2, "C:\\Users\\Students\\Downloads\\resources_sda_project\\2nd.png");

        LoginScreen loginScreen = new LoginScreen();
        //DBHandler.resetInstance();
    }
}