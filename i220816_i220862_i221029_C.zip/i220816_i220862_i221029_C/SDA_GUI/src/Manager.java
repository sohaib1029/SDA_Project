import javax.swing.*;
import java.util.List;

public class Manager {
    private static Manager instance;
    private String id;
    private String name;
    private String address;
    private String email;

    private Manager() {
        id = name = address = email = "";
    }

    public static Manager getInstance() {
        if (instance == null) {
            instance = new Manager();
        }
        return instance;
    }

    // Static method to reset the Singleton instance
    public static void resetInstance() {
        instance = null;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean registerUser(String userID, String fullName, String email, String address, String password, int age) {
        if (age < 18) {
            return false;
        }
        DBHandler.getInstance().addUser(userID, fullName, email, address, password, age);
        return true;
    }

    public void flagPlayer(String userId, boolean isFlagged) {
        DBHandler.getInstance().updateFlaggedStatus(userId, isFlagged);
    }

    public void generateReport() {
//        System.out.println("\n--- Generating Report ---");
//        List<Player> players = playerRepository.getAllPlayers();
//        for (Player player : players) {
//            System.out.println("Player: " + player.getName() + " | Balance: $" + player.getBalance() + " | Flagged: " + player.isFlagged());
//        }
    }
}