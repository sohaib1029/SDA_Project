public class HighRiskGame extends Game {
    HighRiskGame(int id, String name, int payoutMultiplier) {
        super(id, name, payoutMultiplier);
    }
    public boolean play() {
        return Math.random() < 0.3;
    }
}
