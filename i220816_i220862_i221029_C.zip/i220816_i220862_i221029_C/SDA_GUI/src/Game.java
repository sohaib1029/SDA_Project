public class Game {
    private int id;
    private String name;
    private int payoutMultiplier;

    Game(int id, String name, int payoutMultiplier) {
        this.id = id;
        this.name = name;
        this.payoutMultiplier = payoutMultiplier;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPayoutMultiplier() {
        return payoutMultiplier;
    }

    public void setPayoutMultiplier(int payoutMultiplier) {
        this.payoutMultiplier = payoutMultiplier;
    }

    public boolean play() {
        return Math.random() < 0.5;
    }
}
