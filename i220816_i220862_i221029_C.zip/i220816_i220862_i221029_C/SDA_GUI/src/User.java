public class User {
    private static User instance;
    private String id;
    private String name;
    private String address;
    private String email;
    private int balance;
    private int loyaltyPoints;
    private boolean isFlagged;

    private User() {
        id = name = address = email = "";
        balance = loyaltyPoints = 0;
        isFlagged = false;
    }

    public static User getInstance() {
        if (instance == null) {
            instance = new User();
        }
        return instance;
    }

    // Static method to reset the Singleton instance
    public static void resetInstance() {
        instance = null;
    }

//    boolean redeemLoyaltyPoints(int points) {
//        if (points > loyaltyPoints) {
//            System.out.println("Insufficient loyalty points. Required: " + points + ", Available: " + loyaltyPoints);
//            return false;
//        }
//        this.loyaltyPoints -= points;
//        System.out.println(name + " redeemed " + points + " loyalty points! Remaining: " + loyaltyPoints);
//        return true;
//    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public int getLoyaltyPoints() {
        return loyaltyPoints;
    }

    public void setLoyaltyPoints(int loyaltyPoints) {
        this.loyaltyPoints = loyaltyPoints;
    }

    public boolean getFlagged() {
        return isFlagged;
    }

    public void setFlagged(boolean flagged) {
        isFlagged = flagged;
    }

    public void updateLoyaltyPoints(int points) {
        loyaltyPoints += points;
        DBHandler.getInstance().updateLoyaltyPoints(id, loyaltyPoints);
    }

    public void updateBalance(int newBalance) {
        this.balance = newBalance;
        DBHandler.getInstance().updateBalance(id, balance);
    }
}