public class NormalGame extends Game {
    NormalGame(int id, String name, int payoutMultiplier) {
        super(id, name, payoutMultiplier);
    }
}