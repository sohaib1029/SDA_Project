import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.MouseAdapter;

public class DepositAndWithdrawScreen {
    JFrame frame;
    JFrame prevFrame;
    JTextField amountText;
    JButton depBtn, withBtn;
    Border defaultBtnBorder;
    Border hoverBtnBorder;
    MouseAdapter buttonMouseListener;
    FocusAdapter buttonFocusListener;
    TransactionManager transactionManager;

    DepositAndWithdrawScreen(JFrame prevFrame) {
        transactionManager = new TransactionManager();
        this.prevFrame = prevFrame;
        defaultBtnBorder = new EtchedBorder(1, Color.DARK_GRAY, Color.DARK_GRAY);
        hoverBtnBorder = new EtchedBorder(1, Color.GRAY, Color.LIGHT_GRAY);
        // Create common mouse and focus listeners
        buttonMouseListener = UIUtils.createButtonMouseListener(defaultBtnBorder, hoverBtnBorder);
        buttonFocusListener = UIUtils.createButtonFocusListener(defaultBtnBorder, hoverBtnBorder);

        frame = UIUtils.createFrame("Casino Management System", 275, 50, 800, 600, true);
        JLayeredPane mainPane = UIUtils.createPane(0, 0, 800, 600);
        JLabel backgroundImageLabel = UIUtils.createLabel("", 0, 0, 800, 600, null, null,  null, null, 0);
        UIUtils.imageIcon(backgroundImageLabel, "C:\\Users\\Students\\Downloads\\resources_sda_project\\background_800_600_1.png");
        UIUtils.imageIcon(frame, "C:\\Users\\Students\\Downloads\\resources_sda_project\\casino_logo.jpg");

        JButton backBtn = UIUtils.createButton("", 15, 15, 50, 50, null, null, false, defaultBtnBorder);
        UIUtils.imageIcon(backBtn, "C:\\Users\\Students\\Downloads\\resources_sda_project\\backBtn.png");
        JButton enterAmountBtn = UIUtils.createButton("Enter", 330, 400, 130, 30, new Font("Comic Sans", Font.BOLD, 22), Color.WHITE, false, defaultBtnBorder);
        depBtn = UIUtils.createButton("Deposit", 250, 220, 120, 30, new Font("Comic Sans", Font.ITALIC, 22), Color.WHITE, false, defaultBtnBorder);
        withBtn = UIUtils.createButton("Withdraw", 430, 220, 120, 30, new Font("Comic Sans", Font.ITALIC, 22), Color.WHITE, false, defaultBtnBorder);

        // Add listeners for all buttons
        addButtonListeners(backBtn, "Back");
        addButtonListeners(enterAmountBtn, "Enter");
        addButtonListeners(depBtn, "Deposit");
        addButtonListeners(withBtn, "Withdraw");

        JLabel amountLabel = UIUtils.createLabel("Amount:", 252, 300, 100, 30, new Font("Comic Sans", Font.ITALIC, 22), Color.WHITE, null, null, 2);
        JLabel loyaltyPoints = UIUtils.createLabel("Loyalty Points: " + User.getInstance().getLoyaltyPoints(), 600, 480, 150, 35, new Font("Comic Sans", Font.ITALIC, 16), Color.WHITE, null, null, 2);
        JLabel funds = UIUtils.createLabel("Funds: " + User.getInstance().getBalance(), 600, 505, 150, 35, new Font("Comic Sans", Font.ITALIC, 16), Color.WHITE, null, null, 2);

        amountText = UIUtils.createTextField(352, 300, 200, 30, new Font("Consolas", Font.PLAIN, 22), Color.BLACK, Color.LIGHT_GRAY, Color.BLACK, "Enter Bet Amount", new Insets(5, 5, -1, 0));

        mainPane.add(backgroundImageLabel, JLayeredPane.DEFAULT_LAYER);
        mainPane.add(backBtn, JLayeredPane.PALETTE_LAYER);
        mainPane.add(enterAmountBtn, JLayeredPane.PALETTE_LAYER);
        mainPane.add(depBtn, JLayeredPane.PALETTE_LAYER);
        mainPane.add(withBtn, JLayeredPane.PALETTE_LAYER);
        mainPane.add(amountLabel, JLayeredPane.PALETTE_LAYER);
        mainPane.add(loyaltyPoints, JLayeredPane.PALETTE_LAYER);
        mainPane.add(funds, JLayeredPane.PALETTE_LAYER);
        mainPane.add(amountText, JLayeredPane.PALETTE_LAYER);

        frame.setContentPane(mainPane);
    }

    // Generic method to add mouse, focus, and action listeners to buttons
    private void addButtonListeners(JButton button, String buttonLabel) {
        button.addActionListener(createButtonActionListener(buttonLabel));
        button.addMouseListener(buttonMouseListener);
        button.addFocusListener(buttonFocusListener);
    }

    // Method to create button-specific action listeners
    private ActionListener createButtonActionListener(String buttonLabel) {
        return new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton source = (JButton) e.getSource();
                switch (buttonLabel) {
                    case "Back":
                        System.out.println("Back button clicked!");
                        frame.dispose();
                        prevFrame.setVisible(true);
                        break;
                    case "Deposit":
                    case "Withdraw":
                        depBtn.setContentAreaFilled(false);
                        depBtn.setBackground(null);
                        withBtn.setContentAreaFilled(false);
                        withBtn.setBackground(null);
                        source.setContentAreaFilled(true);
                        source.setBackground(Color.DARK_GRAY);
                        break;
                    case "Enter":
                        source.setContentAreaFilled(true);
                        source.setBackground(Color.DARK_GRAY);

                        // Use a timer to revert the appearance after a short delay (delay of 100 ms i.e., click and release)
                        Timer timer = new Timer(100, event -> {
                            source.setBackground(UIManager.getColor("Button.background"));
                            source.setContentAreaFilled(false);
                        });
                        timer.setRepeats(false);
                        timer.start();

                        // Determine which option is selected
                        boolean isDepositSelected = depBtn.getBackground().equals(Color.DARK_GRAY);
                        boolean isWithdrawSelected = withBtn.getBackground().equals(Color.DARK_GRAY);
                        if (!isDepositSelected && !isWithdrawSelected) {
                            JOptionPane.showMessageDialog(
                                    frame,
                                    "Please select an option (Deposit/Withdraw)!",
                                    "No Option Selected",
                                    JOptionPane.WARNING_MESSAGE
                            );
                            return;
                        }

                        String amount = amountText.getText().trim();
                        if (amount.isEmpty()) {
                            JOptionPane.showMessageDialog(
                                    frame,
                                    "Please enter amount!",
                                    "Missing Details",
                                    JOptionPane.WARNING_MESSAGE
                            );
                            return;
                        }

                        if (isDepositSelected) {
                            int res = transactionManager.handleDeposit(Integer.parseInt(amount));
                            if (res == 1) {
                                JOptionPane.showMessageDialog(
                                        frame,
                                        "Access denied: You are flagged for suspicious behavior.",
                                        "User Flagged",
                                        JOptionPane.ERROR_MESSAGE
                                );
                            }
                            else if (res == 2) {
                                JOptionPane.showMessageDialog(
                                        frame,
                                        "Withdrawal failed: Amount must be greater than zero.",
                                        "Incorrect Amount.",
                                        JOptionPane.ERROR_MESSAGE
                                );
                            }
                            else {
                                JOptionPane.showMessageDialog(
                                        frame,
                                        "Deposit successful! New balance: $" + User.getInstance().getBalance(),
                                        "Deposit Successful",
                                        JOptionPane.INFORMATION_MESSAGE
                                );
                            }
                        }
                        else {
                            int res = transactionManager.handleWithdraw(Integer.parseInt(amount));
                            if (res == 1) {
                                JOptionPane.showMessageDialog(
                                        frame,
                                        "Access denied: You are flagged for suspicious behavior.",
                                        "User Flagged",
                                        JOptionPane.ERROR_MESSAGE
                                );
                            }
                            else if (res == 2) {
                                JOptionPane.showMessageDialog(
                                        frame,
                                        "Withdrawal failed: Amount must be greater than zero.",
                                        "Incorrect Amount.",
                                        JOptionPane.ERROR_MESSAGE
                                );
                            }
                            else if (res == 3) {
                                JOptionPane.showMessageDialog(
                                        frame,
                                        "Insufficient balance. Please top up your account.",
                                        "Insufficient Balance",
                                        JOptionPane.ERROR_MESSAGE
                                );
                            }
                            else {
                                JOptionPane.showMessageDialog(
                                        frame,
                                        "Withdrawal successful! New balance: $" + User.getInstance().getBalance(),
                                        "Withdrawal Successful",
                                        JOptionPane.INFORMATION_MESSAGE
                                );
                            }
                        }
                        amountText.setText("");
                        break;
                }
            }
        };
    }
}
