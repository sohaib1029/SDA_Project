import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.*;

public class UIUtils {
    // Common mouse listener for buttons
    public static MouseAdapter createButtonMouseListener(Border defaultBtnBorder, Border hoverBtnBorder) {
        return new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                JButton source = (JButton) e.getSource();
                source.setBorder(hoverBtnBorder); // Change to hover border
            }

            @Override
            public void mouseExited(MouseEvent e) {
                JButton source = (JButton) e.getSource();
                source.setBorder(defaultBtnBorder); // Change to default border
            }
        };
    }

    // Common focus listener for buttons
    public static FocusAdapter createButtonFocusListener(Border defaultBtnBorder, Border hoverBtnBorder) {
        return new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                JButton source = (JButton) e.getSource();
                source.setBorder(hoverBtnBorder); // Change to hover border
            }

            @Override
            public void focusLost(FocusEvent e) {
                JButton source = (JButton) e.getSource();
                source.setBorder(defaultBtnBorder); // Change to default border
            }
        };
    }

    public static JFrame createFrame(String title, int x, int y, int width, int height, boolean isExitOnClose) {
        JFrame frame = new JFrame(title);
        frame.setLocation(x, y);
        frame.setSize(width, height);
        frame.setResizable(false);
        frame.setLayout(null);
        if (isExitOnClose) {
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }
        else {
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        }
        frame.setVisible(true);
        return frame;
    }

    public static JDialog createDialog(JFrame frame, String title, int width, int height) {
        JDialog jDialog = new JDialog();
        jDialog.setLayout(null);
        jDialog.setTitle(title);
        jDialog.setSize(width, height);
        jDialog.setLocationRelativeTo(frame);
        jDialog.getContentPane().setBackground(Color.GRAY);
        jDialog.setModal(true); // Make it modal (blocks parent window interaction)
        return jDialog;
    }

    public static JPanel createPanel(int x, int y, int width, int height, Color bckg, boolean opaque, LayoutManager layoutManager) {
        JPanel jPanel = new JPanel();
        jPanel.setBounds(x, y, width, height);
        jPanel.setLayout(layoutManager);
        if (bckg != null) {
            jPanel.setBackground(bckg);
        }
        if (!opaque) {
            jPanel.setOpaque(false);
        }
        return jPanel;
    }

    public static JLabel createLabel(String text, int x, int y, int width, int height, Font font, Color color, Color bckg, Border border, int align) {
        JLabel label = new JLabel(text);
        label.setBounds(x, y, width, height);
        label.setHorizontalAlignment(align);
        if (font != null)
            label.setFont(font);
        if (color != null)
            label.setForeground(color);
        if (bckg != null)
            label.setBackground(bckg);
        if (border != null)
            label.setBorder(border);
        return label;
    }

    public static JButton createButton(String text, int x, int y, int width, int height, Font font, Color foreground, boolean contentAreaFilled, Border border) {
        JButton button = new JButton(text);
        button.setBounds(x, y, width, height);
        button.setFont(font);
        button.setFocusable(false);
        button.setForeground(foreground);
        if (!contentAreaFilled) {
            button.setContentAreaFilled(false);
        }
        if (border != null) {
            button.setBorder(border);
        }
        else {
            button.setBorder(null);
        }
        return button;
    }

    public static JButton createRewardButton(boolean contentAreaFilled, Border border) {
        JButton button = new JButton();
        button.setFocusable(false);
        button.setContentAreaFilled(false);
        if (border != null) {
            button.setBorder(border);
        }
        else {
            button.setBorder(null);
        }
        return button;
    }

    public static JLayeredPane createPane(int x, int y, int width, int height) {
        JLayeredPane pane = new JLayeredPane();
        pane.setBounds(x, y, width, height);
        pane.setLayout(null);
        return pane;
    }

    public static JTextField createTextField(int x, int y, int width, int height, Font font, Color foreground, Color background, Color caretColor, String toolTipText, Insets margin) {
        JTextField textField = new JTextField();
        textField.setBounds(x, y, width, height);
        textField.setFont(font);
        textField.setForeground(foreground);
        textField.setBackground(background);
        textField.setCaretColor(caretColor);  // Set caret color (text cursor)
        textField.setToolTipText(toolTipText);  // Set tooltip text
        textField.setMargin(margin);  // Set margin for text field
        return textField;
    }

    public static JPasswordField createPassField(int x, int y, int width, int height, Font font, Color foreground, Color background, Color caretColor, String toolTipText, Insets margin) {
        JPasswordField jPasswordField = new JPasswordField();
        jPasswordField.setBounds(x, y, width, height);
        jPasswordField.setFont(font);
        jPasswordField.setForeground(foreground);
        jPasswordField.setBackground(background);
        jPasswordField.setCaretColor(caretColor);
        jPasswordField.setToolTipText(toolTipText);
        jPasswordField.setMargin(margin);
        jPasswordField.setEchoChar('●'); // Mask the password
        return jPasswordField;
    }

    public static JComboBox createComboBox(String[] arr, int x, int y, int width, int height, Font font, String toolTipText) {
        JComboBox comboBox = new JComboBox(arr);
        comboBox.setBounds(x, y, width, height);
        comboBox.setFont(font);
        comboBox.setToolTipText(toolTipText);  // Set tooltip text
        return comboBox;
    }

    public static void imageIcon(JLabel label, String imagePath) {
        ImageIcon icon = new ImageIcon(imagePath);
        label.setIcon(icon);
    }

    public static void imageIcon(JFrame frame, String imagePath) {
        ImageIcon icon = new ImageIcon(imagePath);
        frame.setIconImage(icon.getImage());
    }

    public static void imageIcon(JDialog jDialog, String imagePath) {
        ImageIcon icon = new ImageIcon(imagePath);
        jDialog.setIconImage(icon.getImage());
    }

    public static void imageIcon(JButton button, String imagePath) {
        ImageIcon icon = new ImageIcon(imagePath);
        button.setIcon(icon);
    }
}
