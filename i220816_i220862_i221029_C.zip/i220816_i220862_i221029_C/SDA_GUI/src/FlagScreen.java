import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.MouseAdapter;
import java.util.List;

public class FlagScreen {
    JFrame frame;
    JFrame prevFrame;
    JComboBox usersComboBox;
    Border defaultBtnBorder;
    Border hoverBtnBorder;
    MouseAdapter buttonMouseListener;
    FocusAdapter buttonFocusListener;
    private DBFacade dbFacade;

    FlagScreen(JFrame prevFrame) {
        dbFacade = new DBFacade();
        this.prevFrame = prevFrame;
        defaultBtnBorder = new EtchedBorder(1, Color.DARK_GRAY, Color.DARK_GRAY);
        hoverBtnBorder = new EtchedBorder(1, Color.GRAY, Color.LIGHT_GRAY);
        // Create common mouse and focus listeners
        buttonMouseListener = UIUtils.createButtonMouseListener(defaultBtnBorder, hoverBtnBorder);
        buttonFocusListener = UIUtils.createButtonFocusListener(defaultBtnBorder, hoverBtnBorder);

        frame = UIUtils.createFrame("Casino Management System", 275, 50, 800, 600, true);
        JLayeredPane mainPane = UIUtils.createPane(0, 0, 800, 600);
        JLabel backgroundImageLabel = UIUtils.createLabel("", 0, 0, 800, 600, null, null,  null, null, 0);
        UIUtils.imageIcon(backgroundImageLabel, "C:\\Users\\Students\\Downloads\\resources_sda_project\\background_800_600_1.png");
        UIUtils.imageIcon(frame, "C:\\Users\\Students\\Downloads\\resources_sda_project\\casino_logo.jpg");

        // Add Combo Box with Casino Games
        List<String> userIds = dbFacade.getAllUserIds();
        usersComboBox = UIUtils.createComboBox(userIds.toArray(new String[0]), 300, 215, 200, 30, new Font("Comic Sans", Font.BOLD, 16), "Select Game");
        usersComboBox.setSelectedIndex(-1);

        JButton backBtn = UIUtils.createButton("", 15, 15, 50, 50, null, null, false, defaultBtnBorder);
        UIUtils.imageIcon(backBtn, "C:\\Users\\Students\\Downloads\\resources_sda_project\\backBtn.png");
        JButton flagBtn = UIUtils.createButton("Flag", 265, 450, 130, 30, new Font("Comic Sans", Font.BOLD, 22), Color.WHITE, false, defaultBtnBorder);
        JButton unFlagBtn = UIUtils.createButton("Unflag", 425, 450, 130, 30, new Font("Comic Sans", Font.BOLD, 22), Color.WHITE, false, defaultBtnBorder);

        // Add listeners for all buttons
        addButtonListeners(backBtn, "Back");
        addButtonListeners(flagBtn, "Flag");
        addButtonListeners(unFlagBtn, "Unflag");

        JLabel usersLabel = UIUtils.createLabel("Registered Users", 300, 175, 200, 35, new Font("Comic Sans", Font.ITALIC, 22), Color.WHITE, null, hoverBtnBorder, 0);

        mainPane.add(backgroundImageLabel, JLayeredPane.DEFAULT_LAYER);
        mainPane.add(backBtn, JLayeredPane.PALETTE_LAYER);
        mainPane.add(flagBtn, JLayeredPane.PALETTE_LAYER);
        mainPane.add(unFlagBtn, JLayeredPane.PALETTE_LAYER);
        mainPane.add(usersLabel, JLayeredPane.PALETTE_LAYER);
        mainPane.add(usersComboBox, JLayeredPane.PALETTE_LAYER);
        frame.setContentPane(mainPane);
    }

    // Generic method to add mouse, focus, and action listeners to buttons
    private void addButtonListeners(JButton button, String buttonLabel) {
        button.addActionListener(createButtonActionListener(buttonLabel));
        button.addMouseListener(buttonMouseListener);
        button.addFocusListener(buttonFocusListener);
    }

    // Method to create button-specific action listeners
    private ActionListener createButtonActionListener(String buttonLabel) {
        return new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton source = (JButton) e.getSource();
                source.setContentAreaFilled(true);
                source.setBackground(Color.GRAY);

                // Use a timer to revert the appearance after a short delay (delay of 100 ms i.e., click and release)
                Timer timer = new Timer(100, event -> {
                    source.setBackground(UIManager.getColor("Button.background"));
                    source.setContentAreaFilled(false);
                });
                timer.setRepeats(false);
                timer.start();
                switch (buttonLabel) {
                    case "Back":
                        System.out.println("Back button clicked!");
                        frame.dispose();
                        prevFrame.setVisible(true);
                        break;
                    case "Flag":
                        System.out.println("Flag button clicked!");
                        String selectedUser = (String) usersComboBox.getSelectedItem();
                        if (selectedUser != null) {
                            Manager.getInstance().flagPlayer(selectedUser, true);
                            usersComboBox.setSelectedIndex(-1);
                            JOptionPane.showMessageDialog(
                                    frame,
                                    selectedUser + " has been flagged!",
                                    "User Flagged",
                                    JOptionPane.INFORMATION_MESSAGE
                            );
                        }
                        else {
                            JOptionPane.showMessageDialog(
                                    frame,
                                    "No user selected to flag.",
                                    "Error",
                                    JOptionPane.ERROR_MESSAGE
                            );
                        }
                        break;
                    case "Unflag":
                        System.out.println("Unflag button clicked!");
                        selectedUser = (String) usersComboBox.getSelectedItem();
                        if (selectedUser != null) {
                            Manager.getInstance().flagPlayer(selectedUser, false);
                            usersComboBox.setSelectedIndex(-1);
                            JOptionPane.showMessageDialog(
                                    frame,
                                    selectedUser + " has been unflagged!",
                                    "User Flagged",
                                    JOptionPane.INFORMATION_MESSAGE
                            );
                        }
                        else {
                            JOptionPane.showMessageDialog(
                                    frame,
                                    "No user selected to unflag.",
                                    "Error",
                                    JOptionPane.ERROR_MESSAGE
                            );
                        }
                        break;
                }
            }
        };
    }
}
