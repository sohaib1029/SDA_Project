import java.util.List;

public class DBFacade {
    private DBHandler dbHandler;

    public DBFacade() {
        this.dbHandler = DBHandler.getInstance(); // Singleton instance
    }

    public boolean authenticateUser(String userID, String password, boolean isAdmin) {
        return dbHandler.authenticateUser(userID, password, isAdmin);
    }

    public void getUserDetails(String id, User user) {
        dbHandler.getUserDetails(id, user);
    }

    public void getManagerDetails(String id, Manager manager) {
        dbHandler.getManagerDetails(id, manager);
    }

    public List<String> getAllUserIds() {
        return dbHandler.getAllUserIds();
    }

    // Add other database-related methods as needed
}
